# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

##---(Wed Aug 17 13:52:59 2016)---
cd
exit()
dir
dir()
cd \
